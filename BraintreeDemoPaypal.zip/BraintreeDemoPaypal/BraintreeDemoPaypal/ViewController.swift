//
//  ViewController.swift
//  BraintreeDemoPaypal
//
//  Created by Vishvesh ibl@2019 on 13/05/20.
//  Copyright © 2020 human.solutions. All rights reserved.
//

import UIKit
import Braintree

class ViewController: UIViewController {

    
    @IBOutlet weak var paybutton: UIButton!
    
    let activityIndicator = UIActivityIndicatorView()
    var braintreeClient: BTAPIClient!
        
    @IBAction func PayAction(_ sender: Any) {
        paybutton.isHidden = true
        activityIndicator.startAnimating()
        
        let payPalDriver = BTPayPalDriver(apiClient: braintreeClient)
        payPalDriver.viewControllerPresentingDelegate = self
        payPalDriver.appSwitchDelegate = self
        
        let request = BTPayPalRequest(amount: "10.99")
        request.currencyCode = "USD"

        payPalDriver.requestOneTimePayment(request) { (tokenizedPayPalAccount, error) in
            
            if let tokenizedPayPalAccount = tokenizedPayPalAccount {
                //MARK:-Success
                print("Got a nonce: \(tokenizedPayPalAccount.nonce)")
                
                let email = tokenizedPayPalAccount.email!.replacingOccurrences(of: "\"", with: "", options: .literal, range: nil)
                let firstName = tokenizedPayPalAccount.firstName!.replacingOccurrences(of: "\"", with: "", options: .literal, range: nil)
                let lastName = tokenizedPayPalAccount.lastName!.replacingOccurrences(of: "\"", with: "", options: .literal, range: nil)
               // let phone = tokenizedPayPalAccount.phone
               // let billingAddress = tokenizedPayPalAccount.billingAddress
               // let shippingAddress = tokenizedPayPalAccount.shippingAddress
                
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "SuccessViewController") as? SuccessViewController
                self.navigationController?.pushViewController(vc!, animated: true)
                
                self.alertView(title: "Success!!", message: "\nEmail : \(email)\n\nFirstname : \(firstName)\n\nLastname : \(lastName)")
                
                self.activityIndicator.stopAnimating()
                self.paybutton.isHidden = false
                
            } else if error != nil {
                //MARK:-Failed
                self.alertView(title: "Failed!!", message: "Your payment is not Complete for some reasons")
                self.activityIndicator.stopAnimating()
                self.paybutton.isHidden = false
                
            } else {
                //MARK:-Canceled
                self.alertView(title: "Canceled!!", message: "Payment Canceled!")
                self.activityIndicator.stopAnimating()
                self.paybutton.isHidden = false
                
            }
        }
               
    }
    
    //MARK:-Lifecycles
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.isHidden = true
        braintreeClient = BTAPIClient(authorization: "sandbox_9qjsjpny_k9gthmthfds246fj")!
        
        activityIndicator.center = view.center
        activityIndicator.style = .medium
        view.addSubview(activityIndicator)
    }

    func alertView(title:String,message:String){
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let ok = UIAlertAction(title: "Ok", style: .default, handler: nil)
        alert.addAction(ok)
        present(alert,animated: true)
    }
    
}


//MARK:-BTViewControllerPresentingDelegate Methos
extension ViewController : BTViewControllerPresentingDelegate{
    func paymentDriver(_ driver: Any, requestsPresentationOf viewController: UIViewController) {
    }
    
    func paymentDriver(_ driver: Any, requestsDismissalOf viewController: UIViewController) {
    }
}

//MARK:-BTAppSwitchDelegate Methos
extension ViewController : BTAppSwitchDelegate{
    func appSwitcherWillPerformAppSwitch(_ appSwitcher: Any) {
    }
    
    func appSwitcher(_ appSwitcher: Any, didPerformSwitchTo target: BTAppSwitchTarget) {
    }
    
    func appSwitcherWillProcessPaymentInfo(_ appSwitcher: Any) {
    }
}
