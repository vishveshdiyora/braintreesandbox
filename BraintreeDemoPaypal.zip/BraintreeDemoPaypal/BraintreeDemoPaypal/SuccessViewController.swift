//
//  SuccessViewController.swift
//  BraintreeDemoPaypal
//
//  Created by Vishvesh ibl@2019 on 13/05/20.
//  Copyright © 2020 human.solutions. All rights reserved.
//

import UIKit

class SuccessViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.isHidden = true
        navigationController?.interactivePopGestureRecognizer?.isEnabled = false
    }
    
}
